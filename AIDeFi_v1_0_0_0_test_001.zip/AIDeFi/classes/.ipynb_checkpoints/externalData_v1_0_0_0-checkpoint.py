class externalData:
    
    def ___init__(self, name):
        self.name = name
        